<div class="content">
        <div class="content">
          <div class="container-fluid">
            <div class="row">
              <div class="col-md-4">
                <div class="card ">
                  <div class="card-header card-header-success card-header-icon">
                    <div class="card-icon">
                      <i class="material-icons"></i>
                    </div>
                    <h4 class="card-title">User Register</h4>
                  </div>
                  <div class="card-body ">
                    <h3>Jumlah : 10</h3>
                       
                          </div>
                          </div>
                        </div>
                 <div class="col-md-4">
                <div class="card ">
                  <div class="card-header card-header-success card-header-icon">
                    <div class="card-icon">
                      <i class="material-icons">person</i>
                    </div>
                    <h4 class="card-title">User Verifikasi</h4>
                  </div>
                  <div class="card-body ">
                    <h3>Jumlah : 10</h3>
                       
                          </div>
                          </div>
                        </div>
						<div class="col-md-4">
                <div class="card ">
                  <div class="card-header card-header-success card-header-icon">
                    <div class="card-icon">
                      <i class="material-icons"></i>
                    </div>
                    <h4 class="card-title">Home</h4>
                  </div>
                  <div class="card-body ">
                    <h3>Jumlah : 10</h3>
                       
                          </div>
                          </div>
                        </div>
				 
                      </div>
                    </div>
                  </div>
                
              </div>